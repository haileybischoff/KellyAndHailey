/*
 * game.h
 *
 *  Created on: Oct 20, 2017
 *      Author: superman
 */

#ifndef GAME_H_
#define GAME_H_

#include <stdint.h>

void spaceInvaders_tick();

#endif /* GAME_H_ */
