The following files were generated for 'chipscope_ila_0' in directory
C:\Users\joshuas2\Desktop\427\implementation\chipscope_ila_0_wrapper\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * chipscope_ila_0.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * chipscope_ila_0.cdc
   * chipscope_ila_0.ejp
   * chipscope_ila_0.ncf
   * chipscope_ila_0.ngc
   * chipscope_ila_0_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * chipscope_ila_0.asy

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * chipscope_ila_0.gise
   * chipscope_ila_0.xise

Deliver Readme:
   Readme file for the IP.

   * chipscope_ila_0_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * chipscope_ila_0_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

